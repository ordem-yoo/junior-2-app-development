# 앱개발 중간고사 시험문제

[![Video Label](http://img.youtube.com/vi/HdqZ4gZ2mVQ/0.jpg)](https://youtu.be/HdqZ4gZ2mVQ)


1. 프로젝트를 아래의 조건으로 생성하세요 (30점)
### 프로젝트명 : midterm_[본인학번]
### package name : kr.ac.mjc.midterm_[본인학번]
![스크린샷 2022-10-18 오전 10 59 17](https://user-images.githubusercontent.com/21700482/196317737-036b30f2-8317-4eea-8219-8fd17fa5c21e.png)


2. 실행후 첫화면을 다음과 같이 나오게 하세요 (20점)

![스크린샷 2022-10-18 오전 11 02 59](https://user-images.githubusercontent.com/21700482/196318157-0a9f956b-ec03-4597-aee3-e418eb2e124b.png)

3. 위의 화면에서 아이디를 [본인의학번] 패스워드를 [1234] 를 입력했을때 다음화면으로 넘어가도록 만드세요 (20점)
(로그인정보가 틀릴경우 [아이디 또는 패스워드가 틀렸습니다] 라고 toast가 뜨게 하세요)

4. RecyclerView 를 이용하여 아래와같이 [본인이름+숫자] 로 1~100 까지의 이름리스트가 뜨도록 만드세요(30점)
![스크린샷 2022-10-18 오전 11 06 35](https://user-images.githubusercontent.com/21700482/196318614-430cfd92-4463-4120-af1e-25658858f6c1.png)
